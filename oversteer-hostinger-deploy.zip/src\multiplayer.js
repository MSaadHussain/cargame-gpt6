import * as THREE from 'three';
import { createCar } from './car.js';
import { VEHICLES } from './physics.js';

export function createMultiplayer(scene, callbacks = {}) {
  const remotes = new Map();
  let socket, selfId, room, lastSent = 0;
  const status = (message, active = false) => callbacks.onStatus?.(message, room, active);
  const count = () => callbacks.onCount?.(remotes.size + (selfId ? 1 : 0));
  const payload = getMeta => ({ name: 'Driver', ...getMeta() });
  function remove(id) {
    const remote = remotes.get(id); if (!remote) return;
    scene.remove(remote.car.root); remote.car.wheels.forEach(wheel => scene.remove(wheel)); remotes.delete(id); count();
  }
  function updateRemote(data) {
    if (!data || data.id === selfId) return;
    let remote = remotes.get(data.id);
    if (!remote) {
      const car = createCar(scene); car.setCockpit(false);
      remote = { car, target: new THREE.Vector3(), targetQ: new THREE.Quaternion(), vehicle: null, braking: false };
      remotes.set(data.id, remote); count();
    }
    if (remote.vehicle !== data.vehicle) { remote.car.setProfile(VEHICLES[data.vehicle] || VEHICLES.veloce); remote.vehicle = data.vehicle; }
    remote.car.paint.color.set(data.paint || '#67877d'); remote.braking = Boolean(data.braking);
    remote.target.set(data.x || 0, data.y || 1, data.z || 0);
    remote.targetQ.set(data.qx || 0, data.qy || 0, data.qz || 0, data.qw ?? 1).normalize();
  }
  function connect(type, getMeta, code = '') {
    socket?.close();
    const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
    socket = new WebSocket(`${protocol}//${location.host}/ws`); status('CONNECTING');
    socket.addEventListener('open', () => socket.send(JSON.stringify({ t: type, room: code, ...payload(getMeta) })));
    socket.addEventListener('message', event => {
      let packet; try { packet = JSON.parse(event.data); } catch { return; }
      if (packet.t === 'welcome') { selfId = packet.id; room = packet.room; status(`ROOM ${room}`, true); count(); callbacks.onJoined?.(room, packet.public); packet.players.forEach(updateRemote); }
      else if (packet.t === 'join') updateRemote(packet.player);
      else if (packet.t === 'state') updateRemote(packet.player);
      else if (packet.t === 'leave') remove(packet.id);
      else if (packet.t === 'error') { status(packet.message.toUpperCase()); socket.close(); }
    });
    socket.addEventListener('close', () => { if (selfId) { selfId = null; status('OFFLINE'); count(); } });
    socket.addEventListener('error', () => socket.close());
  }
  return {
    quick: getMeta => connect('quick', getMeta),
    create: getMeta => connect('create', getMeta),
    join: (code, getMeta) => connect('join', getMeta, code.trim().toUpperCase()),
    invite: () => { const url = new URL(location.href); url.searchParams.set('room', room); return url.href; },
    autoJoin(getMeta) { const code = new URL(location.href).searchParams.get('room'); if (code) connect('join', getMeta, code); },
    update(local) {
      if (socket?.readyState === WebSocket.OPEN && selfId && performance.now() - lastSent > 50) { lastSent = performance.now(); socket.send(JSON.stringify({ t: 'state', ...local })); }
      for (const remote of remotes.values()) {
        remote.car.root.position.lerp(remote.target, 0.22); remote.car.root.quaternion.slerp(remote.targetQ, 0.22);
        const offsets = [[-.94,.08,-1.43],[.94,.08,-1.43],[-.94,.08,1.43],[.94,.08,1.43]];
        offsets.forEach((point, index) => remote.car.wheels[index].position.set(...point).applyQuaternion(remote.car.root.quaternion).add(remote.car.root.position));
        remote.car.wheels.forEach(wheel => wheel.quaternion.copy(remote.car.root.quaternion));
        remote.car.materials.red.emissiveIntensity = remote.braking ? 2.2 : .32;
      }
    },
  };
}
