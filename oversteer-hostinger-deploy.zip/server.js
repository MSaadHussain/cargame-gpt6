import { createServer } from 'node:http';
import { createReadStream, existsSync } from 'node:fs';
import { extname, join as pathJoin, normalize, resolve } from 'node:path';
import { randomUUID } from 'node:crypto';
import { WebSocketServer, WebSocket } from 'ws';

const port = Number(process.env.PORT || 3000);
const dist = resolve('dist');
const rooms = new Map();
const MAX_PLAYERS = 8;
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.woff2': 'font/woff2' };
const roomCode = value => String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 10);
const newCode = () => randomUUID().replace(/-/g, '').slice(0, 6).toUpperCase();
const clean = (value, fallback, size) => String(value ?? fallback).replace(/[<>]/g, '').trim().slice(0, size) || fallback;
const finite = (value, fallback, max = 10000) => Number.isFinite(Number(value)) ? Math.max(-max, Math.min(max, Number(value))) : fallback;

function publicPlayer(player) { const { ws, ...data } = player; return data; }
function send(ws, data) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); }
function broadcast(room, data, except) { const message = JSON.stringify(data); for (const player of room.players.values()) if (player.ws !== except && player.ws.readyState === WebSocket.OPEN) player.ws.send(message); }
function quit(player) { if (!player?.room) return; const room = rooms.get(player.room); if (!room) return; room.players.delete(player.id); broadcast(room, { t: 'leave', id: player.id }); if (!room.players.size) rooms.delete(player.room); player.room = null; }
function createRoom(map, isPublic) { let code = newCode(); while (rooms.has(code)) code = newCode(); const room = { code, map, public: isPublic, players: new Map() }; rooms.set(code, room); return room; }
function choosePublic(map) { return [...rooms.values()].find(room => room.public && room.map === map && room.players.size < MAX_PLAYERS) || createRoom(map, true); }
function join(ws, current, room, meta) {
  if (room.players.size >= MAX_PLAYERS) return send(ws, { t: 'error', message: 'This room is full.' });
  quit(current);
  const player = { id: randomUUID().slice(0, 8), room: room.code, ws, name: clean(meta.name, 'Driver', 16), map: room.map, vehicle: meta.vehicle === 'marlin' ? 'marlin' : 'veloce', paint: clean(meta.paint, '#67877d', 12), x: 0, y: 1, z: 0, qx: 0, qy: 0, qz: 0, qw: 1, braking: false };
  send(ws, { t: 'welcome', id: player.id, room: room.code, public: room.public, players: [...room.players.values()].map(publicPlayer) });
  room.players.set(player.id, player); broadcast(room, { t: 'join', player: publicPlayer(player) }, ws); return player;
}

const server = createServer((req, res) => {
  if (!req.url || req.method !== 'GET') { res.writeHead(405); return res.end(); }
  const pathname = decodeURIComponent(new URL(req.url, `http://${req.headers.host || 'localhost'}`).pathname);
  const relativePath = pathname === '/' ? 'index.html' : pathname.replace(/^[/\\]+/, '');
  const candidate = normalize(pathJoin(dist, relativePath));
  const file = candidate.startsWith(dist) && existsSync(candidate) ? candidate : pathJoin(dist, 'index.html');
  if (!existsSync(file)) { res.writeHead(503, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Build missing. Run npm run build.'); }
  res.writeHead(200, { 'Content-Type': mime[extname(file)] || 'application/octet-stream', 'Cache-Control': extname(file) === '.html' ? 'no-cache' : 'public, max-age=31536000, immutable' });
  createReadStream(file).pipe(res);
});

const wss = new WebSocketServer({ noServer: true, maxPayload: 8192 });
server.on('upgrade', (req, socket, head) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  if (url.pathname !== '/ws') return socket.destroy();
  wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws));
});
wss.on('connection', ws => {
  let player = null; ws.alive = true; ws.on('pong', () => { ws.alive = true; });
  ws.on('message', raw => {
    let packet; try { packet = JSON.parse(raw.toString()); } catch { return; } if (!packet || typeof packet !== 'object') return;
    const meta = { name: packet.name, map: clean(packet.map, 'portside', 20), vehicle: packet.vehicle, paint: packet.paint };
    if (packet.t === 'quick') { player = join(ws, player, choosePublic(meta.map), meta) || player; return; }
    if (packet.t === 'create') { player = join(ws, player, createRoom(meta.map, false), meta) || player; return; }
    if (packet.t === 'join') { const room = rooms.get(roomCode(packet.room)); if (!room) return send(ws, { t: 'error', message: 'Room code not found.' }); player = join(ws, player, room, meta) || player; return; }
    if (packet.t !== 'state' || !player) return;
    const room = rooms.get(player.room); if (!room) return;
    player.x = finite(packet.x, player.x); player.y = finite(packet.y, player.y, 100); player.z = finite(packet.z, player.z); player.qx = finite(packet.qx, player.qx, 1); player.qy = finite(packet.qy, player.qy, 1); player.qz = finite(packet.qz, player.qz, 1); player.qw = finite(packet.qw, player.qw, 1); player.braking = Boolean(packet.braking); player.vehicle = packet.vehicle === 'marlin' ? 'marlin' : 'veloce'; player.paint = clean(packet.paint, player.paint, 12);
    broadcast(room, { t: 'state', player: publicPlayer(player) }, ws);
  });
  ws.on('close', () => quit(player)); ws.on('error', () => quit(player));
});
setInterval(() => { for (const ws of wss.clients) { if (!ws.alive) ws.terminate(); else { ws.alive = false; ws.ping(); } } }, 30000);
server.listen(port, '0.0.0.0', () => console.log(`Oversteer multiplayer listening on ${port}`));
