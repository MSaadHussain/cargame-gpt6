import { modelOf } from './vehicleModels.js';

/**
 * The car's shape, defined once as a sequence of calls against an emitter.
 *
 * The player's car runs this against an emitter that builds individually
 * addressable meshes, because impact deformation has to move single panels.
 * Traffic runs the same definition against an emitter that merges everything
 * into one geometry per material, so every AI car is the same model drawn from
 * a handful of instanced meshes.
 */
export function defineCarBody(api, options = {}) {
  if (options.model && !['veloce', 'marlin'].includes(options.model)) return defineVariant(api, options);
  const { part, beam, windowQuad } = api;
  const interior = options.interior !== false;
  const detail = options.detail !== false;

  // Main body panels. These are the ones that take dents.
  part(1.91, 0.44, 4.38, 0, 0.22, 0, 'paint', 0.11, true);
  part(1.83, 0.18, 1.34, 0, 0.51, -1.44, 'paint', 0.07, true);
  part(1.85, 0.18, 0.85, 0, 0.51, 1.7, 'paint', 0.06, true);
  part(1.52, 0.1, 1.81, 0, 1.11, 0.08, 'paint', 0.055, true);
  part(1.86, 0.09, 4.05, 0, 0.04, 0, 'dark', 0.025);

  windowQuad([[-0.84, 0.6, -1.14], [0.84, 0.6, -1.14], [0.72, 1.075, -0.8], [-0.72, 1.075, -0.8]], 'front');
  windowQuad([[0.84, 0.6, 1.24], [-0.84, 0.6, 1.24], [-0.72, 1.075, 0.92], [0.72, 1.075, 0.92]], 'rear');

  for (const s of [-1, 1]) {
    windowQuad([[s * 0.85, 0.59, -1.1], [s * 0.85, 0.59, 1.18], [s * 0.735, 1.07, 0.88], [s * 0.735, 1.07, -0.77]], 'side');
    beam([s * 0.85, 0.57, -1.14], [s * 0.74, 1.11, -0.8], 0.075, 'paint');
    beam([s * 0.85, 0.57, 1.26], [s * 0.74, 1.11, 0.92], 0.105, 'paint');
    beam([s * 0.86, 0.59, 0.05], [s * 0.75, 1.095, 0.05], 0.072, 'trim');
    part(0.045, 0.056, 3.96, s * 0.961, 0.245, 0, 'trim');
    if (detail) {
      part(0.026, 0.035, 2.52, s * 0.944, 0.575, 0.06, 'chrome');
      part(0.022, 0.025, 0.28, s * 0.966, 0.47, -0.04, 'chrome', 0.009);
      part(0.022, 0.025, 0.28, s * 0.966, 0.47, 0.91, 'chrome', 0.009);
      part(0.007, 0.34, 0.012, s * 0.962, 0.37, 0.2, 'dark');
      part(0.007, 0.31, 0.012, s * 0.962, 0.36, 1.18, 'dark');
      part(0.007, 0.31, 0.012, s * 0.962, 0.36, -1.05, 'dark');
      part(0.018, 0.053, 0.14, s * 0.963, 0.46, -1.29, 'headlight');
    }
    // Mirrors, lights and bumper corners read at any distance, so traffic keeps them.
    part(0.25, 0.16, 0.31, s * 1.01, 0.69, -0.85, 'paint', 0.06);
    part(0.19, 0.10, 0.02, s * 1.024, 0.7, -0.686, 'chrome', 0.025);
    part(0.68, 0.18, 0.065, s * 0.53, 0.4, -2.171, 'headlight', 0.025, true);
    part(0.66, 0.16, 0.075, s * 0.56, 0.42, 2.175, 'red', 0.025, true);
    part(0.6, 0.027, 0.08, s * 0.56, 0.40, 2.19, 'chrome');
    part(0.17, 0.12, 0.12, s * 0.66, 0.12, -2.18, 'headlight', 0.025);
  }

  part(0.42, 0.19, 0.05, 0, 0.4, -2.2, 'trim', 0.02);
  if (detail) for (let i = -3; i <= 3; i++) part(0.013, 0.14, 0.06, i * 0.05, 0.4, -2.23, 'chrome');
  part(1.82, 0.085, 0.12, 0, 0.21, -2.2, 'trim', 0.03, true);
  part(1.82, 0.085, 0.12, 0, 0.20, 2.2, 'trim', 0.03, true);
  part(0.8, 0.095, 0.055, 0, 0.07, -2.16, 'dark');
  if (detail) part(0.15, 0.12, 0.26, -0.65, -0.01, 2.17, 'chrome', 0.05);

  if (interior) {
    for (const x of [-0.43, 0.43]) {
      part(0.55, 0.15, 0.57, x, 0.37, 0.12, 'dark', 0.06);
      part(0.55, 0.55, 0.13, x, 0.65, 0.41, 'dark', 0.05, false, { rotateX: -0.12 });
      part(0.27, 0.18, 0.12, x, 0.99, 0.44, 'dark', 0.05);
    }
    part(1.49, 0.35, 0.25, 0, 0.64, 0.99, 'dark', 0.06);
    part(1.6, 0.16, 0.45, 0, 0.58, -0.88, 'dark', 0.055);
    part(1.5, 0.04, 0.04, 0, 0.565, -0.63, 'chrome');
    part(0.24, 0.28, 0.57, 0, 0.33, -0.4, 'dark', 0.03);
  } else {
    // Traffic still needs something behind the glass, but only a suggestion of it.
    part(1.3, 0.42, 1.5, 0, 0.62, 0.1, 'dark', 0.05);
  }
}

function defineVariant({ part, beam, windowQuad }, options) {
  const m = modelOf(options.model), w = m.width, end = m.length / 2;
  const rear = m.cabinRear, roof = m.roof;
  const pickup = m.kind === 'pickup', sport = m.kind === 'sport';
  // Each silhouette has its own cabin, deck and equipment, rather than scaling a sedan.
  part(w, .44, m.length, 0, .22, 0, 'paint', .09, true);
  part(w * .96, .12, .9, 0, .5, -end + .47, 'paint', .04, true);
  part(w * .94, .09, m.length * .96, 0, .02, 0, 'dark');
  part(w * .76, .1, rear + .82, 0, roof, (rear - .82) / 2, 'paint', .045, true);
  windowQuad([[-w*.43,.56,-1.14],[w*.43,.56,-1.14],[w*.37,roof-.06,-.82],[-w*.37,roof-.06,-.82]], 'front');
  windowQuad([[w*.43,.56,rear+.16],[-w*.43,.56,rear+.16],[-w*.37,roof-.06,rear],[w*.37,roof-.06,rear]], 'rear');
  for (const s of [-1, 1]) {
    windowQuad([[s*w*.44,.56,-1.1],[s*w*.44,.56,rear+.12],[s*w*.375,roof-.06,rear-.03],[s*w*.375,roof-.06,-.8]], 'side');
    beam([s*w*.44,.52,-1.15],[s*w*.38,roof,-.82],.075,'paint');
    beam([s*w*.44,.52,rear+.2],[s*w*.38,roof,rear],.1,'paint');
    part(.24,.14,.27,s*w*.52,.66,-.87,'paint',.04);
    part(w*.3,sport ? .08 : .18,.07,s*w*.29,.41,-end-.025,'headlight',.02,true);
    part(w*.3,.12,.07,s*w*.29,.41,end+.025,'red',.02,true);
    part(.04,.13,m.length*.8,s*w*.51,.08,0,'trim');
    part(.035,.035,.25,s*w*.5,.48,-.18,'chrome');
  }
  part(w*.85,.13,.14,0,.18,-end,'trim',.03,true);
  part(w*.85,.13,.14,0,.18,end,'trim',.03,true);
  part(w*.35,.2,.08,0,.38,-end-.015,'dark');
  if (pickup) {
    part(w*.84,.07,2,0,.48,end-1.04,'dark');
    for (const s of [-1,1]) part(.14,.42,2.15,s*(w/2-.09),.66,end-1.09,'paint',.03,true);
    part(w,.42,.13,0,.66,end-.07,'paint',.03,true);
    for (const s of [-1,1]) beam([s*.7,.53,.4],[s*.7,1.2,.4],.1,'chrome');
    beam([-.7,1.2,.4],[.7,1.2,.4],.1,'chrome');
  } else if (m.kind === 'suv' || m.kind === 'hatch') {
    part(w*.86,.35,.12,0,.66,end-.1,'paint',.03,true);
    if (m.kind === 'suv') {
      for (const s of [-1,1]) part(.07,.09,2.05,s*.65,roof+.14,.3,'trim');
      part(.65,.65,.27,0,.69,end+.13,'rubber',.19);
      part(.4,.4,.03,0,.69,end+.28,'chrome',.15);
    }
  } else {
    part(w*.92,.15,end-rear-.15,0,.53,(end+rear+.15)/2,'paint',.04,true);
  }
  if (sport || m.kind === 'rally') {
    for (const s of [-1,1]) part(.07,.32,.12,s*.61,.76,end-.38,'trim');
    part(w*1.03,.07,.38,0,.95,end-.38,'dark',.02);
    part(w*1.05,.06,.36,0,.02,-end+.03,'dark');
    part(.54,.13,.48,0,.63,-1.48,'dark',.03);
    if (m.kind === 'rally') {
      for (const x of [-.55,-.18,.18,.55]) part(.23,.23,.12,x,.59,-end-.08,'headlight',.08);
      part(.3,.01,.8,0,.575,-1.52,'red');
      for (const s of [-1,1]) part(.32,.01,rear+.76,s*.43,roof+.055,(rear-.82)/2,'red');
    }
  }
  if (options.interior !== false) {
    part(w*.77,.15,.4,0,.59,-.88,'dark',.04);
    for (const x of [-.43,.43]) {
      part(.52,.13,.5,x,.37,0,'dark',.04);
      part(.52,.48,.12,x,.65,.29,'dark',.04);
    }
  }
}

// Wheel construction, shared so traffic rolls on the same rims as the player.
export function defineWheel(api, options = {}) {
  const { cylinder, box, torus } = api;
  const detail = options.detail !== false;
  cylinder(0.36, 0.36, 0.235, 32, 'rubber', 0, 0);
  for (const side of [-1, 1]) {
    cylinder(0.25, 0.25, 0.018, 32, 'chrome', side * 0.124, 0);
    cylinder(0.208, 0.208, 0.019, 32, 'dark', side * 0.137, 0);
    for (let j = 0; j < 8; j++) box(0.024, 0.405, 0.045, side * 0.15, j * Math.PI / 8, 'chrome');
    cylinder(0.075, 0.075, 0.027, 16, 'chrome', side * 0.16, 0);
    if (detail) torus(0.3, 0.006, 4, 32, 'trim', side * 0.12);
  }
}
