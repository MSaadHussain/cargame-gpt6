import * as CANNON from 'cannon-es';

import { FLIGHT_LIMIT, FLIGHT_CEILING } from './airCombatRules.js';
export { flightSpawn, FLIGHT_LIMIT, FLIGHT_CEILING } from './airCombatRules.js';
export function resetFlight(physics) {
  physics.flight={throttle:.65,speed:95,pitch:0,roll:0,heading:0,crashed:false};
}
// Arcade flight assistance: speed-controlled thrust, banked turns, automatic roll
// levelling and gentle stalls. No expensive aerodynamic simulation on the relay.
export function stepFlight(physics,input,dt) {
  const f=physics.flight,b=physics.chassis,heavy=physics.spec.id==='skyliner';
  if(f.crashed||physics.damage>=100){b.velocity.setZero();return;}
  const clamp=(v,a,c)=>Math.max(a,Math.min(c,v));
  f.throttle=clamp(f.throttle+((input.forward?1:0)-(input.backward?1:0))*dt*.4,0,1);
  const pitch=clamp(input.pitchAxis||0,-1,1),bank=clamp(input.rollAxis||0,-1,1),rudder=clamp(input.yawAxis||0,-1,1);
  f.pitch=clamp(f.pitch+pitch*dt*(heavy?.33:.68),-.95,.95);
  f.roll+=((bank||rudder*.65)*(heavy?.75:1.15)-f.roll)*Math.min(1,dt*(heavy?1.5:3));
  f.heading+=(Math.sin(f.roll)*(heavy?.35:.65)+rudder*(heavy?.2:.45))*dt;
  const max=heavy?175:240,target=25+f.throttle*max+(input.boost&&!heavy?65:0);
  f.speed+=(target-f.speed)*Math.min(1,dt*.3);
  if(b.position.y>FLIGHT_CEILING)f.pitch=Math.min(f.pitch,-.15);
  if(Math.max(Math.abs(b.position.x),Math.abs(b.position.z))>FLIGHT_LIMIT) {
    f.heading=Math.atan2(b.position.x,b.position.z);f.pitch=clamp(f.pitch,-.15,.15);
  }
  b.quaternion.setFromEuler(f.pitch,f.heading,f.roll,'YXZ');
  const forward=b.quaternion.vmult(new CANNON.Vec3(0,0,-1));
  b.velocity.copy(forward.scale(f.speed));
  if(f.speed<55)b.velocity.y-=(55-f.speed)*.65;
  b.angularVelocity.setZero();b.force.setZero();b.torque.setZero();
  physics.world.step(dt);
  const ground=heavy?4:1.2;
  if(b.position.y<ground) {
    const runway=Math.abs(b.position.x)<45&&Math.abs(b.position.z)<1500;
    if(runway&&b.velocity.y>-7&&Math.abs(f.roll)<.2&&f.speed<105) {
      b.position.y=ground;b.velocity.y=0;f.pitch=Math.max(0,f.pitch);
    } else {b.position.y=ground;f.crashed=true;physics.damage=100;b.velocity.setZero();}
  }
  physics.throttle=f.throttle;physics.rpm=physics.spec.idleRpm+f.throttle*(physics.spec.maxRpm-physics.spec.idleRpm);
  physics.gear=1;physics.braking=!!input.backward;physics.distance+=f.speed*dt;physics.steer=bank*.4;
}
