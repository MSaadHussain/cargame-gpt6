import * as THREE from 'three';
import { ovalRoute } from './route.js';

export function buildFlightWorld(b) {
  const ground=new THREE.Mesh(new THREE.PlaneGeometry(14000,14000),b.material('#71896c'));
  ground.rotation.x=-Math.PI/2;ground.position.y=-.1;ground.receiveShadow=true;b.own(ground.geometry);b.attach(ground);
  // Long runway, taxiways, hangars and terminal: instanced boxes, no thousands of colliders.
  b.box(0,0,0,90,.12,3000,'#38434b');
  b.box(190,0,0,48,.12,3000,'#68716c');
  for(const z of [-1200,0,1200])b.box(95,0,z,150,.13,55,'#68716c');
  for(let z=-1400;z<=1400;z+=100){b.box(0,.08,z,3,.03,48,'#eeece0');for(const s of [-1,1])b.box(s*44,.2,z,1.2,.4,2,'#d6e3a6');}
  for(const z of [-1440,1440])for(let x=-32;x<=32;x+=8)b.box(x,.08,z,4,.04,65,'#eeece0');
  b.box(380,0,0,340,.1,900,'#9b9f91');
  const mapBuildings=[];
  for(let z=-900;z<=900;z+=300){b.box(350,17,z,110,34,95,'#afb9b5');b.box(294,11,z,1,22,65,'#344651');mapBuildings.push({x:350,z,w:110,d:95});}
  b.box(530,26,0,95,52,220,'#c9c5b1');b.box(530,56,0,120,10,245,'#567682');
  b.box(240,40,-450,18,80,18,'#c6cabb');b.box(240,83,-450,42,10,42,'#385566');
  b.box(-1800,-.03,0,1000,.1,10000,'#4d91a5');
  // A low-detail mountain ring is scenery, outside the playable flight boundary.
  const mountainGeo=new THREE.ConeGeometry(1,1,5);b.own(mountainGeo);
  const mountains=new THREE.InstancedMesh(mountainGeo,b.material('#7a8384'),36),dummy=new THREE.Object3D();
  for(let i=0;i<36;i++){const angle=i/36*Math.PI*2,r=6400;dummy.position.set(Math.cos(angle)*r,200+i%4*80,Math.sin(angle)*r);dummy.scale.set(650,400+i%4*160,650);dummy.updateMatrix();mountains.setMatrixAt(i,dummy.matrix);}
  mountains.computeBoundingSphere();b.attach(mountains);
  const cloudGeo=new THREE.IcosahedronGeometry(1,0);b.own(cloudGeo);
  const clouds=new THREE.InstancedMesh(cloudGeo,b.material('#e2e9e8'),54);
  for(let i=0;i<54;i++){dummy.position.set(Math.sin(i*2.4)*4500,1100+i%5*90,Math.cos(i*1.8)*4500);dummy.scale.set(100+i%3*50,30,90);dummy.updateMatrix();clouds.setMatrixAt(i,dummy.matrix);}
  clouds.computeBoundingSphere();b.attach(clouds);
  return {mapBuildings,roads:[],dynamics:[],route:ovalRoute({straight:2800,radius:150,lanes:2,laneWidth:40,segments:20}),fog:{color:'#b8d3e0',near:4000,far:10500},sky:'#a9d2e9'};
}
