import * as THREE from 'three';
import { createCar } from './car.js';
import { VEHICLES } from './physics.js';
import { modelOf } from './vehicleModels.js';
import { RemoteCollisions } from './remoteCollisions.js';

function nameTag(name) {
  const canvas = document.createElement('canvas'); canvas.width = 320; canvas.height = 72;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(18,29,27,.82)'; ctx.beginPath(); ctx.roundRect(8,8,304,56,18); ctx.fill();
  ctx.fillStyle = '#f5f2e8'; ctx.font = '600 29px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(name,160,37,285);
  const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace;
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false }));
  sprite.scale.set(2.6,.585,1); return sprite;
}

export function createMultiplayer(scene, physics, callbacks = {}) {
  const remotes = new Map(), collisions = new RemoteCollisions(physics);
  let socket, selfId, room, lastSent = 0;
  const status = (message, active = false) => callbacks.onStatus?.(message, room, active);
  function remove(id) {
    const remote = remotes.get(id);
    if (remote) { remote.car.dispose(); remotes.delete(id); }
    collisions.remove(id);
  }
  function clear() { [...remotes.keys()].forEach(remove); collisions.clear(); selfId = null; }
  function updateRemote(data) {
    if (!data?.ready || data.id === selfId) return;
    let remote = remotes.get(data.id);
    if (!remote) {
      const car = createCar(scene), tag = nameTag(data.name || 'Driver'); car.root.add(tag);
      remote = { car, tag, target: new THREE.Vector3(), targetQ: new THREE.Quaternion(), vehicle: null, received: 0 };
      car.root.position.set(data.x,data.y,data.z); remotes.set(data.id, remote);
    }
    if (remote.vehicle !== data.vehicle) {
      remote.car.setProfile(VEHICLES[data.vehicle] || VEHICLES.veloce); remote.vehicle = data.vehicle;
      remote.tag.position.y = modelOf(data.vehicle).roof + .8;
    }
    remote.car.paint.color.set(data.paint || '#67877d'); remote.data = data; remote.received = performance.now();
    remote.target.set(data.x,data.y,data.z); remote.targetQ.set(data.qx,data.qy,data.qz,data.qw).normalize();
    if (remote.car.root.position.distanceTo(remote.target) > 12) remote.car.root.position.copy(remote.target);
    collisions.receive(data, remote.received);
  }
  function connect(type, getMeta, code = '') {
    const old = socket; socket = null; old?.close(); clear(); status('OFFLINE');
    const ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws');
    socket = ws; status('CONNECTING');
    ws.addEventListener('open', () => { if (socket === ws) ws.send(JSON.stringify({t:type,room:code,...getMeta()})); });
    ws.addEventListener('message', event => {
      if (socket !== ws) return;
      let p; try { p = JSON.parse(event.data); } catch { return; }
      if (p.t === 'welcome') {
        selfId = p.id; room = p.room; lastSent = 0; status('ROOM ' + room,true);
        callbacks.onRoom?.(p); callbacks.onJoined?.(room,p.public); p.players.forEach(updateRemote);
      } else if (p.t === 'join' || p.t === 'state') updateRemote(p.player);
      else if (p.t === 'traffic') callbacks.onTraffic?.(p.density);
      else if (p.t === 'leave') remove(p.id);
      else if (p.t === 'error') { clear(); status('OFFLINE'); callbacks.onError?.(p.message); ws.close(); }
    });
    ws.addEventListener('close', () => { if (socket === ws) { clear(); socket = null; status('OFFLINE'); } });
    ws.addEventListener('error', () => { if (socket === ws) { status('OFFLINE'); callbacks.onError?.('Could not connect to multiplayer.'); ws.close(); } });
  }
  const send = p => { if (socket?.readyState === WebSocket.OPEN && selfId && socket.bufferedAmount < 16384) socket.send(JSON.stringify(p)); };
  const offsets = new THREE.Vector3();
  return {
    quick: meta => connect('quick',meta), create: meta => connect('create',meta),
    join: (code,meta) => connect('join',meta,code.trim().toUpperCase()),
    setTraffic: density => send({t:'traffic',density}),
    beforeStep: () => collisions.beforeStep(), protectSpawn: () => collisions.protectSpawn(),
    update(local, dt) {
      if (performance.now()-lastSent >= 50) { lastSent = performance.now(); send({t:'state',...local}); }
      for (const remote of remotes.values()) {
        const {car,data} = remote;
        const age = Math.max(0,(performance.now()-remote.received)/1000);
        car.root.visible = age < .75; car.wheels.forEach(w => w.visible = car.root.visible);
        const ahead = Math.min(age,.15);
        remote.target.set(data.x+data.vx*ahead,data.y+data.vy*ahead,data.z+data.vz*ahead);
        car.root.position.lerp(remote.target,1-Math.exp(-dt*22)); car.root.quaternion.slerp(remote.targetQ,1-Math.exp(-dt*22));
        const model = modelOf(remote.vehicle);
        car.wheels.forEach((wheel,i) => {
          offsets.set((i%2 ? 1:-1)*model.width*.492,-.25,(i<2 ? -1:1)*model.wheelbase/2);
          wheel.position.copy(offsets).applyQuaternion(car.root.quaternion).add(car.root.position); wheel.quaternion.copy(car.root.quaternion);
        });
        car.materials.red.emissiveIntensity = data.braking ? 2.2 : .32;
      }
    },
  };
}
